%% Function file (ODEs) for model variants derived from Full HSR module
% Rate parameter: eta1 and eta2 are the translation rates for sigma_32
% before and after heat shock, respectively. The values are adjusted according to the model variant. (The details are provided in the main text Table1)
% a_trans and a_trans_ftsh are the translation rates for chaperones. K represents the Michaelis constant.
% These rates are adjusted according to the model variant. 
% k1 and k2 represents the sequestration of sigma_32 by chaperones which
% are set to zero for feedforward only module.

function HSR2 = HSR_function2(t,y,k1,k2,a,K,eta1,eta2)
% rate constants (microM min)
b1 = 0.03;  % rate of dilution
a_trans=a; % translation rate of chaperones
a_trans_ftsh =a; % translation rate of FtsH
k3=0; % Protease (FtsH) binding to sigma_32.C complex forming sigma_32.C.P complex
k4=0; % Protease (FtsH) unbinding to sigma_32.C complex
k5=59.4; % Chaperones binding to misfolded proteins forming C.M complex
k6=0.372; % Chaperones unbinding to misfolded proteins
k7=108;  % Chaperone mediated unfolding of the misfolded protein (forming C.U complex)
k8=1.08; % Backeard  rate (from C.U to C.M)
k9=120; % Dissociation of C.U complex and release of unfolded protein
k10=1.2; % Backward rate (from U to C.U)
k12=0.12; % transition rate from misfolded to unfolded protein
k13=0.48; % transition rate from folded to unfolded protein
k14=750; % transition rate from unfolded to folded protein
b_deg=0; % rate of degradation of sigma_32

% heat shock
if t<600
    n=eta1; % translation rate of sigma_32
    k11=75; % transition rate from unfolded to misfolded protein
else
    n=eta2; % translation rate of sigma_32 after heat shock
    k11=150; % transition rate from unfolded to misfolded protein after heat shock
end

 HSR2 =[ n - b_deg*y(3) - b1*y(1) %1
       k1*(y(1) - y(2) - y(3))*(y(9) - y(2) - y(3) - y(5) - y(6)) - k2*y(2) + k4*y(3) - k3*(y(10)-y(3))*y(2) %2
       k3*(y(10)-y(3))*y(2) - k4*y(3) - b_deg*y(3) %3
       -k5*(y(9) - y(2) - y(3) - y(5) - y(6))*y(4) + k6*y(5) - k12*y(4) + k11*y(7) %4
       k5*(y(9) - y(2) - y(3) - y(5) - y(6))*y(4) - k6*y(5) + k8*y(6) - k7*y(5) %5
       k7*y(5) - k8*y(6) - k9*y(6) + k10*(y(9) - y(2) - y(3) - y(5) - y(6))*y(7) %6
       k12*y(4) - k11*y(7) - k14*y(7) + k13*y(8) - k10*(y(9) - y(2) - y(3) - y(5) - y(6))*y(7) + k9*y(6) %7
       -k13*y(8) + k14*y(7) %8
       a_trans*((y(1) - y(2) - y(3))./(K + (y(1) - y(2) - y(3)))) - b1*y(9)  %9
       a_trans_ftsh*((y(1) - y(2) - y(3))./(K + (y(1) - y(2) - y(3)))) - b1*y(10)  %10
    ];
end