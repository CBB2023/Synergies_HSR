%% Generate figure 2: Trade-off between Response time and Benefit-to-Cost

% keep all the function files and figure2.m file in one folder.
% HSR_function.m defines the full HSR model (ODEs). Parameters are defined
% within the file.
% HSR_function2.m defines the model variants (ODEs) including feedforward only 
% and feedforward with sequestrations.  
% Function_folding.m defines the protein folding in the absence of
% chaperones.
% Details regarding the function files and parameters are given within them. 
% run figure2.m file
% it will generate the figure 2 of the paper. To keep it simple, the code for inset figure is not included.


