%% Figure2: Trade-off between Response Time and Benefit-to-Cost
clear; close all; clc;

% initial conditions (micro M)
y0 = [0.196 0.02 0.02 2 0.2 0.3 0.6 4996.9 15 5]; % full HSR module  
y01 = [0.04 0 0 2 0.2 0.3 0.6 4996.9 15 5]; % other two modules 

% time span
tspan = linspace(0,900,200000);

%---- Solving ODEs corresponsing to each module ----%
[t1,y1] = ode15s(@Function_folding,tspan,[0 0 5000]); % without chaperone 
[t2,y2] = ode15s(@(t,y) HSR_function2(t,y,0,0,0.5,0.0667,0.0009,0.0036),tspan, y01); %Feedforward only
[t3,y3] = ode15s(@(t,y) HSR_function2(t,y,19.8,0.372,1.2,0.00417,0.0009,0.0036),tspan,y01); %Feedforward + sequestration
[t4,y4] = ode15s(@(t,y) HSR_function(t,y),tspan,y0); %Full HSR

% for comparable response time
% we have ehnaced the translation rate of sigma_32 (eta) and chaperones (a_trans and K_sigma) to match
% the response time of full HSR module.
[t22,y22] = ode15s(@(t,y) HSR_function2(t,y,0,0,0.62,0.0464,0.0007,0.03),tspan, y01); %Feedforward only
[t33,y33] = ode15s(@(t,y) HSR_function2(t,y,19.8,0.372,1.5,0.0032,0.0009,0.005),tspan,y01); %Feedforward + sequestration

% Protein folding in the absence of chaperones
M_values = y1(:, 1); %Misfolded proteins
U_values = y1(:, 2); %Unfolded proteins
F_values = y1(:, 3); %Folded proteins

% Production rate of chaperones
pp1= 0.5*((y2(:,1) - y2(:,2) - y2(:,3))./(0.0667 + (y2(:,1) - y2(:,2) - y2(:,3)))); %Feedforward
pp2= 1.2*((y3(:,1) - y3(:,2) - y3(:,3))./(0.00417 + (y3(:,1) - y3(:,2) - y3(:,3)))); %Feedforward + sequestration
pp3= 2*((y4(:,1) - y4(:,2) - y4(:,3))./(0.05 + (y4(:,1) - y4(:,2) - y4(:,3)))); %Full HSr

% Folded proteins 
f2=y2(:,8); %Feedforward
f22=y22(:,8);
f3=y3(:,8); %Feedforward + sequestration
f33=y33(:,8);
f4=y4(:,8); %Full HSR

% Benefit-to-Cost Ratio
a1=(y2(:,8)-F_values)./y2(:,9); %Feedforward
a11=(y22(:,8)-F_values)./y22(:,9);
a2=(y3(:,8)-F_values)./y3(:,9); %Feedforward + sequestration
a22=(y33(:,8)-F_values)./y33(:,9);
a3=(y4(:,8)-F_values)./y4(:,9); %Full HSR

% Total heat shock factor concentration
s2=y2(:,1); %Feedforward
s3=y3(:,1); %Feedforward + sequestration
s4=y4(:,1); %Full HSR

%% Ploting Figure2: Trade-off between Response Time and Benefit-to-Cost
% heat shock is introduced after the HSR system has reached the steady-state
% therefore the plot is generated after t=550 min and heat shock is
% introduced at t=600 min (10 min after steady-state is achieved)
f=figure();
set(gcf,'Position',[680,298,941,580]);
subplot(2,3,1);
plot(t2(t2>=550),s2(t2>=550),'DisplayName', 'Temp. sensor','Color','r',LineWidth=1.5,Marker='.');
hold on;
plot(t3(t3>=550),s3(t3>=550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>=550),s4(t4>=550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
xlabel('Time (min)');
ylabel('[\sigma_{32}]_t (\muM)');
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 700]);
xticks(600:30:700)           % set tick positions
xticklabels(xticks - 590)

subplot(2,3,2);
plot(t1(t1>550),F_values(t1>550),'DisplayName', 'No chaperone rescue','Color','k', LineWidth=1.5);
hold on;
plot(t2(t2>550),f2(t2>550),'DisplayName', 'Temp sensor','Color','r',LineWidth=1.5);
plot(t3(t3>550),f3(t3>550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>550),f4(t4>550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
xlabel('Time');
ylabel('Folded proteins (\mu M)');
legend('Position',[0.442838640174035,0.690248598276183,0.176408072872192,0.119827582918364]);
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 750]);
xticks(600:40:750)           % set tick positions
xticklabels(xticks - 590)

subplot(2,3,3);
plot(t1(t1>550),F_values(t1>550),'DisplayName', 'No chaperone rescue','Color','k', LineWidth=1.5);
hold on;
plot(t22(t22>550),f22(t22>550),'DisplayName', 'Temp. sensor','Color','r',LineWidth=1.5);
plot(t33(t33>550),f33(t33>550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>550),f4(t4>550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
xlabel('Time');
ylabel('Folded proteins (\mu M)');
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 750]);
xticks(600:40:750)           % set tick positions
xticklabels(xticks - 590)

subplot(2,3,4);
plot(t2(t2>=550),pp1(t2>=550),'DisplayName', 'Temp. sensor','Color','r',LineWidth=1.5);
hold on;
plot(t3(t3>=550),pp2(t3>=550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>=550),pp3(t4>=550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
xlabel('Time (min)');
ylabel('Production rate (\muM min^{-1})');
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 700]);
xticks(600:40:700)           % set tick positions
xticklabels(xticks - 590)

subplot(2,3,5);
plot(t2(t2>550),a1(t2>550),'DisplayName', 'Temp Sensor','Color','r',LineWidth=1.5);
hold on;
plot(t3(t3>550),a2(t3>550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>550),a3(t3>550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
hold off; 
xlabel('Time (min)');
ylabel('\eta_{bc}');
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 810]);
xticks(600:50:810)           % set tick positions
xticklabels(xticks - 590)

subplot(2,3,6)
plot(t22(t22>550),a11(t22>550),'DisplayName', 'Temp. sensor','Color','r',LineWidth=1.5);
hold on;
plot(t33(t33>550),a22(t33>550),'DisplayName', 'Temp. + Seq.','Color','b',LineWidth=1.5);
plot(t4(t4>550),a3(t4>550),'DisplayName', 'Full HSR','Color','m',LineWidth=1.5);
hold off; 
xlabel('Time (min)');
ylabel('\eta_{bc}');
set(gca,'FontName','TimesNewRoman','FontSize',10);
xlim([590 810]);
xticks(600:50:810)           % set tick positions
xticklabels(xticks - 590)