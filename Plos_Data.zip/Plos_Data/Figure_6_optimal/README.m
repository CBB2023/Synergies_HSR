%% Generate Figure6:Optimal Regime of Operation

% keep all the function files and figure_6.m file in one folder.

% HSR_function_3D.m defines the full HSR model (ODEs). Parameters are defined
% within the file. 
% The strengths of feedforward, sequestration, and degradation feedbacks are varied.

 
% Function_folding_3D.m defines the protein folding in the absence of
% chaperones.

% Details regarding the function files and parameters are given within them. 
% run figure_6.m file
% it will generate the figure 6 of the paper.