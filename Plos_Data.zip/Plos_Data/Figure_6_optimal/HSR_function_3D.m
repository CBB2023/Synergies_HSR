%% Defines the full HSR module (ODEs). Parameters are defined within the function.
% Feedforward (ff), sequestration (k1) and degradation strength is varied (b_deg)
function HSR = HSR_function_3D(t,y,k1,b_deg,ff)

% rate constants
b1 = 0.03;  % rate of dilution
a_trans=2; % translation rate of chaperones 
a_trans_ftsh =2; % translation rate of FtsH 
%k1 % chaperone binding to sigma_32 forming sigma_32.C complex
k2=0.372; % chaperone unbinding to sigma_32 
k3=20; % Protease (FtsH) binding to sigma_32.C complex forming sigma_32.C.P complex
k4=0.3; % Protease (FtsH) unbinding to sigma_32.C complex
k5=59.4; % Chaperones binding to misfolded proteins forming C.M complex 
k6=0.372; % Chaperones unbinding to misfolded proteins
k7=108; % Chaperone mediated unfolding of the misfolded protein (forming C.U complex)
k8=1.08; % Backeard  rate (from C.U to C.M)
k9=120; % Dissociation of C.U complex and release of unfolded protein
k10=1.2; % Backward rate (from U to C.U)
k12=0.12; % transition rate from misfolded to unfolded protein
k13=0.48; % transition rate from folded to unfolded protein
k14=750; % transition rate from unfolded to folded protein


% heat shock
if t<300
    n=0.075; % translation rate of sigma_32 (η_T)
    k11=75; % transition rate from unfolded to misfolded protein
else
    n=ff; % η_T rate after heat shock (varied in Figure 5)
    k11=150; % transition rate from unfolded to misfolded protein after heat shock
end
%HSR
HSR =[ n - b_deg*y(3) - b1*y(1) %1
       k1*(y(9) - y(2) - y(3) - y(5) - y(6))*(y(1) - y(2) - y(3)) - k2*y(2) + k4*y(3) - k3*(y(10)-y(3))*y(2) %2
       k3*(y(10)-y(3))*y(2) - k4*y(3) - b_deg*y(3) %3
       -k5*(y(9) - y(2) - y(3) - y(5) - y(6))*y(4) + k6*y(5) + k11*y(7) - k12*y(4) %4
       k5*(y(9) - y(2) - y(3) - y(5) - y(6))*y(4) - k6*y(5) + k8*y(6) - k7*y(5) %5
       k7*y(5) - k8*y(6) + k10*(y(9) - y(2) - y(3) - y(5) - y(6))*y(7)  - k9*y(6)%6
       k12*y(4) - k11*y(7) - k10*(y(9) - y(2) - y(3) - y(5) - y(6))*y(7) + k9*y(6)  - k14*y(7) + k13*y(8)%7
       -k13*y(8) + k14*y(7) %8    
       a_trans*((y(1) - y(2) - y(3))./(0.05 + (y(1) - y(2) - y(3)))) - b1*y(9)  %9
       a_trans_ftsh*((y(1) - y(2) - y(3))./(0.05 + (y(1) - y(2) - y(3)))) - b1*y(10)  %10
    ];
end