%% Figure6:Optimal Regime of Operation
clear; close all; clc;

% The strengths of feedforward, sequestration, and degradation feedbacks are varied.
feedforward = linspace(0.075,4,50); % feedforward
sequestration = logspace(-2,3,60); % sequestration
degradation = logspace(-3,2,50); % degradation

% time span
tspan = linspace(0,600,10000);

%initial conditions
y0 = [0.196 0.02 0.02 2 0.2 0.3 0.6 4996.9 10 5];

% Pre-allocating the memory
response_time = zeros(length(feedforward),length(sequestration),length(degradation));
production_rate_after_shock = zeros(length(feedforward),length(sequestration),length(degradation));
Benefit = zeros(length(feedforward),length(sequestration),length(degradation));
rescue_rate = zeros(length(feedforward),length(sequestration),length(degradation));
Total_Chaperones = zeros(length(feedforward),length(sequestration),length(degradation));
Benefit_to_Cost = zeros(length(feedforward),length(sequestration),length(degradation));
folding_yield = zeros(length(feedforward),length(sequestration),length(degradation));

% Call the ODE function 'Function_folding_3D' and solve the system in the absence of chaperones
[t1,y1] = ode45(@Function_folding_3D,tspan,[0 0 5000]);
F_values = y1(:,3); % Folded proteins in the absence of chaperones

% loop over strengths of feedforward, sequestration, and degradation feedbacks.
for ii = 1:length(feedforward)
    for jj = 1:length(sequestration)
        for kk = 1:length(degradation)

            %---- Call the ODE function 'HSR_function_3D' and solve the system of differential equations
            % representing the full Heat Shock Response (HSR) module using ode15s ----%
            options = odeset('RelTol',1e-8,'AbsTol',1e-10);
            [t,y] = ode15s(@(t,y) HSR_function_3D(t,y,sequestration(jj)*19.8,degradation(kk),feedforward(ii)),tspan,y0,options);
            
            %% -- Calculating Response time -- %%
            t_heat_shock = 300; %time of heat shock
            Folded_protein = y(:,8); %folded proteins
            % Folded proteins before heat shock
            Folded_before_shock = Folded_protein(t<t_heat_shock);
            Folded_before_shock = Folded_before_shock(end);

            % The minimum level of folded proteins (Folded_dropped) and its index
            [Folded_dropped, min_index] = min(Folded_protein(t>=t_heat_shock));

            % The corresponding time when the minimum occurs
            time_after_shock = t(t>=t_heat_shock); 
            t_min = time_after_shock(min_index);

            % The recovery target (97% of pre-shock level)
            Recovery_level = 0.97*Folded_before_shock;

            %Extract protein levels and times after the minimum point
            Folded_after_min = Folded_protein(t>=t_min); 
            time_after_min = t(t>=t_min);

           % Check if folded proteins never drop below the recovery level
            if all(Folded_after_min>=Recovery_level)
                % If protein levels are already above the recovery level, set response time to zero
                response_time(ii,jj,kk) = 0;
            else
                % Find the first time the protein reaches the recovery level
                first_recovery_index = find(Folded_after_min >= Recovery_level,1);
                if isempty(first_recovery_index)
                    response_time(ii,jj,kk) = NaN;
                else
                    first_recovery_time = time_after_min(first_recovery_index);
                    Folded_after_recovery = Folded_protein(t>=first_recovery_time);
                    if any(Folded_after_recovery(end) < Recovery_level)
                        % If recovery level was never reached, assign NaN to response_time
                        response_time(ii,jj,kk) = NaN;
                    else
                        stable_recovery_time = first_recovery_time;
                    end
                    % Assign final response time
                    response_time(ii,jj,kk) = stable_recovery_time - t_heat_shock;
                end
            end
%%
           % production rate of chaperones
           production_rate_chaperones = 2*((y(:,1)-y(:,2)-y(:,3))./(0.05 + (y(:,1)-y(:,2)-y(:,3))));
           
           % production rate after heat shock
           production_rate_after_shock(ii,jj,kk) = mean(production_rate_chaperones(end-10:end));

           % total chaperone concentration
           chaperones_total = y(:,9);
           Total_Chaperones(ii,jj,kk) = mean(chaperones_total(end-10:end));

           % calculating Benefit-to-Cost
           Benefit(ii,jj,kk) = Folded_protein(end)-F_values(end);
           Benefit_to_Cost(ii,jj,kk) = Benefit(ii,jj,kk)./Total_Chaperones(ii,jj,kk);

           % folded proteins
           folded_proteins{ii,jj,kk} = y(:,8); 
 %% -- Calculating the Adaptation time --%%
 % Adaptation time is the sum of rise time and drop time. The rise time and
 % drop time are calculated as follows.
        % Extract indices after heat shock
        idx_after_shock = find(t >= t_heat_shock);
        t_post = t(idx_after_shock);

        % production after heat shock
        prod_post = production_rate_chaperones(idx_after_shock);

        % Find true peak index: first time it reaches max (within numerical tolerance)
        peak_value = max(prod_post);
        tol = 5e-4; % tolerance for floating-point comparison
        peak_idx_rel = find(abs(prod_post - peak_value) < tol, 1, 'first');
        
        t_peak = t_post(peak_idx_rel); % time of peak
        % production rate at peak
        production_rate_peak(ii,jj,kk) = prod_post(peak_idx_rel);
        
        % Rise time
        rise_time(ii,jj,kk) = t_peak - t_heat_shock;
        
        % Steady-state production rate after peak
        prod_after_peak = prod_post(peak_idx_rel:end);
        t_after_peak = t_post(peak_idx_rel:end);
        steady_state_value = mean(production_rate_chaperones(end-20:end));
        
        % Drop time: first time within threshold of steady state
        threshold = 0.01 * (peak_value - steady_state_value);
        
        % If steady state is too close to peak, set drop time to NA
        if abs(steady_state_value - peak_value) <= threshold
            drop_time(ii,jj,kk) = NaN;
        else
            % Check when trajectory crosses into steady-state band from above
        above = prod_after_peak > steady_state_value + threshold;
        
        % Look for first transition from above -> within/below band
        crossings = find(above(1:end-1) & ~above(2:end), 1, 'first');
        
        if isempty(crossings)
            drop_time(ii,jj,kk) = NaN;
        else
            drop_idx_rel = crossings + 1; % index of first point inside band
            drop_time(ii,jj,kk) = t_after_peak(drop_idx_rel) - t_peak;
        end
          
        end
            
        end
    end
end

%% For the normalised performance index
RT_max = max(response_time(:)); % Max Response time
B_C_max = max(Benefit_to_Cost(:)); % Max Benefit-to-Cost

for ii = 1:length(feedforward)
    for jj = 1:length(sequestration)
        for kk = 1:length(degradation)
            % Performance index
            overall_performance(ii,jj,kk) = (Benefit_to_Cost(ii,jj,kk).*(RT_max-response_time(ii,jj,kk)))/(RT_max*B_C_max);
        end
    end
end
%% Plotting Figure6:Optimal Regime of Operation
[X,Y,Z] = meshgrid(sequestration,feedforward,degradation);
[X1,Y1,Z1]=ndgrid(feedforward,sequestration,degradation);

figure();
performance_index = (Benefit_to_Cost(:).*(RT_max-response_time(:)))/(RT_max*B_C_max);
subplot(2,2,1);
scatter3(X1(:),Y1(:),Z1(:),20,performance_index);
shading interp;
xlabel('$\eta$','Interpreter','latex','FontSize',18);
ylabel('$\alpha$','Interpreter','latex','FontSize',18);
zlabel('$\beta$','Interpreter','latex','FontSize',18,'Rotation',0);
set(gca,'YScale','log','ZScale','log');
colormap("jet");
yticks([0.01 1 100]);zticks([0.01 1 100]);

subplot(2,2,2);
slice(X,Y,Z,overall_performance,[],[0.075,1,2,3,4],[]);
hold on;
scatter3(1,0.3,3,30,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'Marker','o'); % wild-type
shading interp;
ylabel('$\eta$','Interpreter','latex','FontSize',18);
xlabel('$\alpha$','Interpreter','latex','FontSize',18);
zlabel('$\beta$','Interpreter','latex','FontSize',18,'Rotation',0); 
alpha(0.9);
set(gca,'XScale','log','ZScale','log');
colormap("jet");
xticks([0.01 1 100]);zticks([0.01 1 100]);

subplot(2,2,3);
slice(X,Y,Z,overall_performance,[1e-2 1e-1 1 1e1 1e2 1e3],[],[]);
hold on;
scatter3(1,0.3,3,30,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'Marker','o'); % wild-type
shading interp;
ylabel('$\eta$','Interpreter','latex','FontSize',18);
xlabel('$\alpha$','Interpreter','latex','FontSize',18);
zlabel('$\beta$','Interpreter','latex','FontSize',18,'Rotation',0); 
alpha(0.9);
set(gca,'XScale','log','ZScale','log');
colormap("jet");
xticks([0.01 1 100]);zticks([0.01 1 100]);

subplot(2,2,4);
slice(X,Y,Z,overall_performance,[],[],[1e-3 1e-2 1e-1 1 1e1 1e2]);
hold on;
scatter3(1,0.3,3,30,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'Marker','o'); % wild-type
shading interp;
ylabel('$\eta$','Interpreter','latex','FontSize',18);
xlabel('$\alpha$','Interpreter','latex','FontSize',18);
zlabel('$\beta$','Interpreter','latex','FontSize',18,'Rotation',0); 
alpha(0.9);
set(gca,'XScale','log','ZScale','log');
colormap("jet");
xticks([0.01 1 100]);zticks([0.01 1 100]);