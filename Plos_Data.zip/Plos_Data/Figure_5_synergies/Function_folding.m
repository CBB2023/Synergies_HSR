%% Function file for protein folding in the absence of chaperones
% Contains ODEs for protein folding, misfolding and unfolding
function dydt = Function_folding(t, y)
    % Extract variables
    M = y(1); %Misfolded
    U = y(2); %Unfolded
    F = y(3); %Folded
    
    % Define rate constants
    if t < 300
        kum = 75; % transition rate from unfolded to misfolded protein
    else
        kum = 150; % transition rate from unfolded to misfolded protein after heat shock
    end
    kmu = 0.12; % transition rate from misfolded to unfolded protein
    kuf = 750; % transition rate from unfolded to folded protein
    kfu = 0.48; % transition rate from folded to unfolded protein
    
    % Define the system of differential equations
    dMdt = kum*U - kmu*M;
    dUdt = kmu*M - kum*U - kuf*U + kfu*F;
    dFdt = kuf*U - kfu*F;
    
    % Return derivatives
    dydt = [dMdt; dUdt; dFdt];
end