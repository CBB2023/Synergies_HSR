%% Generate Figure4:Sequestration Feedback Optimizes the Adaptation Time

% keep all the function files and figure_4.m file in one folder.

% HSR_function.m defines the full HSR model (ODEs). Parameters are defined
% within the file. % Sequestration strength is varied by multiplying alpha to k1 rate. 
% k1 is the rate at which chaperones binds with the sigma_32.
 
% Function_folding.m defines the protein folding in the absence of
% chaperones.

% Details regarding the function files and parameters are given within them. 
% run figure_4.m file
% it will generate the figure 4 of the paper.