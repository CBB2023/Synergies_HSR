%% Figure4:Sequestration Feedback Optimizes the Adaptation Time
clear;close all; clc;

% Sequestration strength is varied by multiplying alpha to k1 rate. 
% k1 is the rate at which chaperones binds with the sigma_32.
alpha = logspace(-2,2,50);

% time span
tspan = linspace(0,900,200000);

% initial conditions (micro M)
y0 = [0.196 0.02 0.02 2 0.2 0.3 0.6 4996.9 15 5];  

% loop over the range of alpha
for ii = 1:length(alpha)

    %---- Call the ODE function 'HSR_function' and solve the system of differential equations
    % representing the full Heat Shock Response (HSR) module using ode15s ----%
    [t4,y4] = ode15s(@(t,y) HSR_function(t,y,19.8*alpha(ii)),tspan,y0); %full HSR
    
    % Call the ODE function 'Function_folding' and solve the system in the absence of chaperones
    [t1,y1] = ode15s(@Function_folding,tspan,[0 0 5000]);

    % Folded proteins in the absence of chaperones
    F_values = y1(:, 3); 
    
    % Concentration of free sigma_32 concentration
    free_sigma_conc(ii,:) = y4(:,1) - y4(:,2) - y4(:,3);

    % production rate of chaperones
    prod_rate = 2*(free_sigma_conc(ii,:))./(0.05 + free_sigma_conc(ii,:));
    
    sigma_total(ii,:) = y4(:,1); % total sigma_32
    Folded(ii,:) = y4(:,8); % folded proteins
    
    %% -- calculating adaptation time --%%
    heat_shock_time = 600; % time of heat shock
    
    % extract indices before heat shock
    sigma_time_idx = find(t4 <= heat_shock_time, 1, 'last');
    % Production rate before heat shock
    prod_rate_pre_stress(ii) = prod_rate(sigma_time_idx);

    % Extract indices after heat shock
    idx_after_shock = find(t4 >= heat_shock_time);
    t_post = t4(idx_after_shock); % time after shock
    % Production rate after heat shock
    prod_post = prod_rate(idx_after_shock);
    
    % Find peak and its index after heat shock
    [peak_value, peak_idx_rel] = max(prod_post);
    t_peak = t_post(peak_idx_rel); % time at which peak occurs
    % production rate at peak
    production_rate_peak(ii) = peak_value;
    
    % Calculate rise time: from heat shock to peak
    rise_time(ii) = t_peak - heat_shock_time;
    
    % Estimate steady-state production rate: average of last 50 values after peak
    prod_after_peak = prod_post(peak_idx_rel:end); %production after peak
    t_after_peak = t_post(peak_idx_rel:end); %Time after peak
    steady_state_value = mean(prod_after_peak(end-49:end)); %steady-state production rate 
     
    % Difference between peak and steady state
    diff_val = peak_value - steady_state_value;
    
    threshold = 0.1 * diff_val; % threshold is set for drop time
    
    % First time when production rate drops to within threshold
    drop_idx = find(abs(prod_after_peak - steady_state_value) <= threshold, 1, 'first');
    
    if ~isempty(drop_idx)
        t_drop = t_after_peak(drop_idx);
        drop_time(ii) = t_drop - t_peak;
    else
        drop_time(ii) = NaN;
        warning('Drop time could not be computed: system may not have reached steady state.');
    end
    
    %% -- calculating response time --%
    t_heat_shock = 600;  %  the time at which the heat shock occurs in minutes
    
    % folded protein level before the heat shock
    Folded_proteins_current = Folded(ii,:);
    Folded_before = Folded_proteins_current(t4 < t_heat_shock);
    Folded_before = Folded_before(end);
    
    % The minimum level of folded proteins (Folded_dropped) and its index
    [Folded_dropped, min_index] = min(Folded_proteins_current(t4 >= t_heat_shock));
    
    % The corresponding time when the minimum occurs
    time_after_shock = t4(t4 >= t_heat_shock);  % Times after the heat shock
    t_min = time_after_shock(min_index);  % Time when the minimum occurred
    
    % The recovery target (97% of pre-shock level)
    Recovery_level = 0.97*Folded_before;
    
    % Extract protein levels and times after the minimum point
    Folded_after_min = Folded_proteins_current(t4 >= t_min);
    time_after_min = t4(t4 >= t_min);
    
    % Check if folded proteins never drop below the recovery level
    if all(Folded_after_min >= Recovery_level)
        % If protein levels are already above the recovery level, set response time to zero
        response_time(ii) = 0;
    else
        % Find the first time the protein reaches the recovery level
        first_recovery_index = find(Folded_after_min >= Recovery_level, 1);
        
        if isempty(first_recovery_index)
            % If recovery level was never reached, assign NaN to response_time
            response_time(ii) = NaN;
        else
            % Tentative recovery time (first crossing)
            first_recovery_time = time_after_min(first_recovery_index);
    
            % Extract protein levels after first recovery event
            Folded_after_recovery = Folded_proteins_current(t4 >= first_recovery_time);
    
            % Check if the protein ever drops below recovery level after first reaching it
            if Folded_proteins_current(end) < Recovery_level
                % If it drops below again, use the last stable crossing
                response_time(ii) = NaN;
            else
                % If it never drops below again, use the first crossing time
                stable_recovery_time = first_recovery_time;
            end
    
            % Assign final response time
            response_time(ii) = stable_recovery_time - t_heat_shock;
        end
    end
end

%% Plotting Figure4:Sequestration Feedback Optimizes the Adaptation Time
figure();
subplot(1,2,1)
hold on;
plot(alpha,production_rate_peak./prod_rate_pre_stress,'-k',LineWidth=1.2);
scatter(alpha,production_rate_peak./prod_rate_pre_stress,35,"green",'filled', 'MarkerEdgeColor', 'black'); 
scatter(1,11.05,40,"red",'filled', 'MarkerEdgeColor', 'black');
ylabel('Fold change in prod. rate');
xlabel('\alpha');
set(gca,'XScale','log');

subplot(1,2,2)
hold on;
plot(alpha,rise_time+drop_time,'-k', LineWidth=1.5);
plot(alpha,response_time,'-k', LineWidth=1.5);
s1=scatter(alpha,rise_time+drop_time,45,"green",'filled', 'MarkerEdgeColor', 'black',DisplayName='Adaptation time');
s2=scatter(alpha,response_time,45,"magenta",'filled', 'MarkerEdgeColor', 'black',DisplayName='Response time');
scatter(1,3.165,40,"red",'filled', 'MarkerEdgeColor', 'black');
scatter(1,4.84,40,"red",'filled', 'MarkerEdgeColor', 'black');
xlabel('\alpha');
ylabel('Overall response (min)')
legend;
set(gca,'XScale','log');
legend([s1 s2], {'Adaptation time','Response time'});