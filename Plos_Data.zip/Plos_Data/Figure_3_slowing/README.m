%% Generate Figure3:Slowing of Response Time at High Feedforward Strength

% keep all the function files and figure_3.m file in one folder.

% HSR_function.m defines the full HSR model (ODEs). Parameters are defined
% within the file. The translation rate (η_T) of sigma_32 was varied after
% heat shock.
 
% Function_folding.m defines the protein folding in the absence of
% chaperones.

% Details regarding the function files and parameters are given within them. 
% run figure_3.m file
% it will generate the figure 3 of the paper.
