%% Figure3:Slowing of Response Time at High Feedforward Strength
clear;close all; clc;

% time span
tspan = linspace(0,900,200000);

%  Range of sigma_32 translation rate (η_T) values explored after heat shock
FF = [0.075,0.1125,0.15,0.225,0.3,0.45,0.6,0.75,1.2,1.8,2.4,3.6,4.8,6,7.2,9.6]; %This parameter controls the synthesis rate of sigma_32 during stress

% initial conditions (micro M)
y0 = [0.196 0.02 0.02 2 0.2 0.3 0.6 4996.9 15 5];  

% loop over the range of sigma_32 translation rate (η_T) 
for ii = 1:length(FF)

    %---- Call the ODE function 'HSR_function' and solve the system of differential equations
    % representing the full Heat Shock Response (HSR) module using ode15s ----%
    [t4,y4] = ode15s(@(t,y) HSR_function(t,y,FF(ii)),tspan,y0); %full HSR

    % Call the ODE function 'Function_folding' and solve the system in the absence of chaperones
    [t1,y1] = ode15s(@Function_folding,tspan,[0 0 5000]); %absence of chaperones

    %Folded proteins in the absence of chaperones
    F_values = y1(:, 3); 

    %-- calculating response time --%
    t_heat_shock = 600;  %  the time at which the heat shock occurs in minutes
    
    % Calculating folded protein level before the heat shock
    Folded(ii,:) = y4(:,8);
    Folded_proteins_current = Folded(ii,:);
    Folded_before = Folded_proteins_current(t4 < t_heat_shock);
    Folded_before = Folded_before(end); %folded protein level before the heat shock
    
    % The minimum level of folded proteins (Folded_dropped) and its index
    [Folded_dropped, min_index] = min(Folded_proteins_current(t4 >= t_heat_shock));
    
    % The corresponding time when the minimum occurs
    time_after_shock = t4(t4 >= t_heat_shock);  % Times after the heat shock
    t_min = time_after_shock(min_index);  % Time when the minimum occurred
    
    % The recovery target (97% of pre-shock level)
    Recovery_level = 0.97*Folded_before;
    
    % Protein levels and times after the minimum point
    Folded_after_min = Folded_proteins_current(t4 >= t_min);
    time_after_min = t4(t4 >= t_min);
    
    % If folded proteins never drop below the recovery level
    if all(Folded_after_min >= Recovery_level)
        % If protein levels are already above the recovery level, set response time to zero
        response_time(ii) = 0;
    else
        % First time the protein reaches the recovery level
        first_recovery_index = find(Folded_after_min >= Recovery_level, 1);
        
        if isempty(first_recovery_index)
            % If recovery level was never reached, assign NaN to response_time
            response_time(ii) = NaN;
        else
            % Tentative recovery time (first crossing)
            first_recovery_time = time_after_min(first_recovery_index);
    
            % Extract protein levels after first recovery event
            Folded_after_recovery = Folded_proteins_current(t4 >= first_recovery_time);
    
            % Check if the protein ever drops below recovery level after first reaching it
            if Folded_proteins_current(end) < Recovery_level
                % If it drops below again, use the last stable crossing
                response_time(ii) = NaN;
            else
                % If it never drops below again, use the first crossing time
                stable_recovery_time = first_recovery_time;
            end
    
            % Assign final response time
            response_time(ii) = stable_recovery_time - t_heat_shock;
        end
    end

    % Folded proteins after heat shock
    Folded_after(ii) = Folded_proteins_current(end);

    % Calculating total chaperone concentration after heat shock
    chaperone_total = y4(:,9);
    chaperone_after(ii) = mean(chaperone_total(end-20:end)); %total chaperone concentration after heat shock

    % Benefit-to-Cost ratio
    efficiency(ii) = (Folded_after(ii)-F_values(end))./chaperone_after(ii);
end
%% Ploting Figure3:Slowing of Response Time at High Feedforward Strength
figure;
set(gcf,'Position',[680,560,765,318]);
subplot(1,2,1);
hold on;
B=response_time; % Response time data
colorid =1:16; % Assign color IDs for plotting
cmap = jet(16);

% Get axis limits
yl = [min(B)-0.1, max(B)+0.1]; 
% Shade region η_T < 0.75 
fill([1e-2, 0.75, 0.75, 1e-2], [yl(1), yl(1), yl(2), yl(2)], [0.9 1 0.9], 'EdgeColor', 'none');
% Shade region η_T > 0.75 
fill([0.75, 11, 11, 0.75], [yl(1), yl(1), yl(2), yl(2)], [1 0.9 0.9], 'EdgeColor', 'none');

% Plot response time as a scatter plot
scatter(FF,response_time,50,colorid,'filled', 'MarkerEdgeColor', 'black');
% Highlight wild-type response
plot(0.3,3.16516,'Marker','square','MarkerSize',10,'LineWidth',2);
hold off;
xlabel('\eta_T (\muM min^{-1})');
ylabel('Response Time (min)');
xlim([0.07 10.2]);
ylim([2.3 5.1]);
set(gca, 'XScale', 'log') % Log scale for η_T

subplot(1,2,2);
hold on;
% Define y-axis limits again for shading
yl = [min(response_time)-0.1, max(response_time)+0.1]; 
% Shade region representing low efficiency (η_T > 0.75)
fill([0, 181.38, 181.38, 0], [yl(1), yl(1), yl(2), yl(2)], [1 0.9 0.9], 'EdgeColor', 'none');
% Shade region representing low efficiency (η_T < 0.75)
fill([181.38, 250, 250, 181.38], [yl(1), yl(1), yl(2), yl(2)], [0.9 1 0.9], 'EdgeColor', 'none');

% Plot response time vs efficiency
scatter(efficiency,response_time,50,colorid,'filled', 'MarkerEdgeColor', 'black');
% Highlight wild-type response
plot(215.192,3.16516,'Marker','square','MarkerSize',10,'LineWidth',2);
hold off;
xlim([80 250]);
ylim([2.3 5.1]);
xlabel('\eta_{bc}');
ylabel('Response Time (min)');